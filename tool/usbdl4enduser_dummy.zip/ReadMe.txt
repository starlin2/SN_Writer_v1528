========================================================================
       CONSOLE APPLICATION : S_USBDL_Dummy
========================================================================


AppWizard has created this S_USBDL_Dummy application for you.  

Sample code here is just to add dummy signature pattern (ex: 256 bytes).
Therefore, skip the processing for K2.bin and K3.bin files.11

S_USBDL_Dummy.dsp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.dsp) file, but they should export the makefiles locally.

S_USBDL_Dummy.cpp
    This is the main application source file.


/////////////////////////////////////////////////////////////////////////////
Other notes:

This is just a sample code to test the secure USB download flow. All of the 
encryption/decryption and signature verification should be implemented by
your own. Please refer to the related slides. Thanks.

/////////////////////////////////////////////////////////////////////////////
